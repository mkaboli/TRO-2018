import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab
from sklearn.decomposition import PCA
from sklearn import preprocessing
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF
from mpl_toolkits.mplot3d import Axes3D
from sklearn.model_selection import cross_val_score

viz = False
viz2d = False
TEMP = []
for obj in [1,2,3,4,5,6,8,9,10]:
	for trial in range(1,11):
		t = np.loadtxt('data/temp_obj'+str(obj)+'_trial'+str(trial)+'.txt')
		# clear the offsets
		for i in range(7):
			t[:,i] = t[:,i]-t[0,i]

		# average temperature change over 7 cells
		t = np.mean(t,axis=1)
		t_sampled = t[0:1000]

		# estimate the temperature slop
		gradient = np.gradient(t_sampled)

		TEMP.append(np.append(t_sampled,gradient))

TEMP = np.array(TEMP)

T = [1]*10+[2]*10+[3]*10+[4]*10+[5]*10+[6]*10+[7]*10+[8]*10+[9]*10

#visualization
if viz:
	cl = ['r','b','g','y','c','m','k',[0.9,0.3,0.1],'0.6','0.3']
	plt.figure()
	for i,c in zip(range(9),cl):
		for j in range(10):
			temp = TEMP[i*10+j]
			x = range(len(temp))
			if j==0:
				plt.plot(x,temp,color=c,linewidth=3,label='obj'+str(i+1))
			else:
				plt.plot(x,temp,color=c,linewidth=3)
	plt.xlabel('time(63Hz)',fontsize=30)
	plt.ylabel('temperature change',fontsize=30)
	plt.legend()
	plt.show()

# run PCA in order to reduce the features
num_ftr = TEMP.shape[1]
std_scale = preprocessing.StandardScaler().fit(TEMP)
TEMP_STD = std_scale.transform(TEMP)
# PCA reduction
pca = PCA(n_components=10).fit(TEMP_STD)
X = pca.transform(TEMP_STD)
d = sum(pca.explained_variance_ratio_)

X = np.array(X)
np.savetxt('X_temp(pca_10d).txt',X)
np.savetxt('T_temp(pca_10d).txt',T)

'''
print 'when PCA reduces to 10 dimensions, the accuracy of cross-validation reaches 80%'
kernel = 1.0 * RBF([1.0])
clf = GaussianProcessClassifier(kernel=kernel).fit(TEMP_STD,T)
scores = cross_val_score(clf, X, T, cv=10)
print np.mean(scores)
'''

###
# plot the results (2D)
###
if viz2d:
	cl = ['r','b','g','y','c','m','k','0.9',[0.9,0.3,0.1],'0.5']
	num_obj = 9
	sample_nr = 10
	for i in range(0,num_obj):
		plt.scatter(X[i*sample_nr:i*sample_nr+sample_nr,0],\
		X[i*sample_nr:i*sample_nr+sample_nr,1],\
		marker='o', s=100,c=cl[i], label='obj'+str(i+1))

		# plot texts
		n = range(sample_nr)
		xx = X[i*sample_nr:i*sample_nr+sample_nr,0]
		yy = X[i*sample_nr:i*sample_nr+sample_nr,1]
		for i, txt in enumerate(n):
			plt.annotate(txt, (xx[i],yy[i]))

	plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
	#plt.xlim([-7,7])
	#plt.ylim([-5,5])
	plt.title("2D_var="+str(round(d,2)),fontsize=15,loc='right')
	plt.show()
